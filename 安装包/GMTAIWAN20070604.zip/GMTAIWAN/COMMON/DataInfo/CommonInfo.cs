using System;
using System.Data;
using System.Data.SqlClient;
using Common.Logic;

namespace Common.DataInfo
{
	/// <summary>
	/// CommonInfo ��ժҪ˵����
	/// </summary>
	public class CommonInfo
	{
		public CommonInfo()
		{
			//
			// TODO: �ڴ˴����ӹ��캯���߼�
			//
		}
        public static int LinkServerIP_Create(int userByID,string gameIP,string usr,string pwd,string city,int gameID,int gamedbID,int gameFlag)
        {
            int result = -1;
            SqlParameter[] paramCode;
            try
            {
                paramCode = new SqlParameter[9]{
                                                   new SqlParameter("@GM_UserID",SqlDbType.Int),
												   new SqlParameter("@Game_IP",SqlDbType.VarChar,30),
												   new SqlParameter("@Game_Usr",SqlDbType.VarChar,50),
												   new SqlParameter("@Game_PWD",SqlDbType.VarChar,50),
                                                   new SqlParameter("@Game_City",SqlDbType.VarChar,50),
                                                   new SqlParameter("@Game_ID",SqlDbType.Int),
                                                   new SqlParameter("@Game_DBID",SqlDbType.Int),
                                                   new SqlParameter("@Game_Flag",SqlDbType.Int),
												   new SqlParameter("@result",SqlDbType.Int)
											   };
                paramCode[0].Value = userByID;
                paramCode[1].Value = gameIP.Trim();
                paramCode[2].Value = usr.Trim();
                paramCode[3].Value = pwd.Trim();
                paramCode[4].Value = city.Trim();
                paramCode[5].Value = gameID;
                paramCode[6].Value = gamedbID;
                paramCode[7].Value = gameFlag;
                paramCode[8].Direction = ParameterDirection.ReturnValue;
                result = SqlHelper.ExecSPCommand("sp_linkGameIP", paramCode);
				if(userByID == 0)
				{
					CommonInfo.SDO_OperatorLogDel(userByID);
				}
            }
            catch (SqlException ex)
            {
                Console.WriteLine(ex.Message);

            }
            return result;
        }
		public static int LinkServerIP_Delete(int userByID,int idx,string gameIP)
		{
			int result = -1;
			SqlParameter[] paramCode;
			try
			{
				paramCode = new SqlParameter[4]{
												   new SqlParameter("@GM_UserID",SqlDbType.Int),
												   new SqlParameter("@idx",SqlDbType.Int),
												   new SqlParameter("@ServerIP",SqlDbType.VarChar,30),
												   new SqlParameter("@Result",SqlDbType.Int)
											   };
				paramCode[0].Value = userByID;
				paramCode[1].Value = idx;
				paramCode[2].Value = gameIP.Trim();
				paramCode[3].Direction = ParameterDirection.ReturnValue;
				result = SqlHelper.ExecSPCommand("sp_deleteLinkDown", paramCode);
				if(userByID == 0)
				{
					CommonInfo.SDO_OperatorLogDel(userByID);
				}
			}
			catch (SqlException ex)
			{
				Console.WriteLine(ex.Message);

			}
			return result;
		}
        public static DataSet serverIP_QueryAll()
        {
            try
            {
                return SqlHelper.ExecuteDataset("ServerInfo_Query_All");
            }
            catch (SqlException ex)
            {
                Console.WriteLine(ex.Message);
                return null;
            }
        }
        public static string serverIP_Query(string serverIP)
        {
            string serverName = null;
			SqlParameter[] paramCode;
            try
            {
				paramCode = new SqlParameter[1]{
												   new SqlParameter("@ServerIP",SqlDbType.VarChar,30)};
			    paramCode[0].Value = serverIP;
                DataSet ds = SqlHelper.ExecSPDataSet("ServerName_Query",paramCode);
                if (ds != null && ds.Tables[0].Rows.Count > 0)
                {
                    serverName = ds.Tables[0].Rows[0].ItemArray[0].ToString();
                }
            }
            catch (SqlException ex)
            {
                Console.WriteLine(ex.Message);
            }
            return serverName;
        }
		public static DataSet serverIP_Query(int gameID,int gameDBID)
		{
            DataSet ds = null;
            SqlParameter[] paramCode;
            try
            {
                paramCode = new SqlParameter[2]{
												   new SqlParameter("@GM_gameID",SqlDbType.Int),
												   new SqlParameter("@GM_gameDBID",SqlDbType.Int)};
                paramCode[0].Value = gameID;
                paramCode[1].Value = gameDBID;
                ds = SqlHelper.ExecSPDataSet("ServerInfo_Query", paramCode);
            }
            catch (SqlException ex)
            {
                Console.WriteLine(ex.Message);
                return null;
            }
            return ds;
		}
		#region �鿴���߲�����¼
		/// <summary>
		/// �鿴���߲�����¼
		/// </summary>
		/// <param name="userID">�û�ID</param>
		/// <param name="beginDate">��ʼ����</param>
		/// <param name="endDate">��������</param>
		/// <returns></returns>
		public static DataSet OperateLog_Query(int userID,DateTime beginDate,DateTime endDate)
		{
			DataSet result = null;
			SqlParameter[] paramCode;
			try
			{
				paramCode = new SqlParameter[3]{
												   new SqlParameter("@Gm_UserID",SqlDbType.Int),
												   new SqlParameter("@BeginDate",SqlDbType.DateTime),
												   new SqlParameter("@EndDate",SqlDbType.DateTime)};
				paramCode[0].Value=userID;
				paramCode[1].Value=beginDate;
				paramCode[2].Value=endDate;
				result = SqlHelper.ExecSPDataSet("GMTools_Log_Query",paramCode);
			}
			catch(SqlException ex)
			{
				Console.WriteLine(ex.Message);
			}
			return result;
		}
		#endregion
		#region ɾ������Ա������־
		/// <summary>
		/// ɾ������Ա������־
		/// </summary>
		/// <param name="userByID">����ԱID</param>
		/// <returns></returns>
		public static int SDO_OperatorLogDel(int userByID)
		{
			int result = -1;
			try
			{
				result = SqlHelper.ExecCommand("delete from  GMTools_Log where UserID = "+userByID);
				result = SqlHelper.ExecCommand("delete from  GMTools_Log_UpdateAgo where UserID = "+userByID);
				result = SqlHelper.ExecCommand("delete from  GMTools_LogTime where OperateUserID = "+userByID);
			}
			catch(System.Data.SqlClient.SqlException ex)
			{
				Console.WriteLine(ex.Message);
			}
			return result;

		}
		#endregion
	}
}
