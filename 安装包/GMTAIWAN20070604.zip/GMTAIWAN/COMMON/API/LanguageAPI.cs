using System;
using System.Configuration;
using System.Collections;

namespace Common.API
{
	/// <summary>
	/// LanguageConfig ��ժҪ˵����
	/// </summary>
	public class LanguageAPI
	{
		public LanguageAPI()
		{
			//
			// TODO: �ڴ˴����ӹ��캯���߼�
			//
		}
		/// <summary>
		/// ����keyֵ�õ�value
		/// </summary>
		/// <param name="game">��Ϸ����</param>
		/// <param name="key">�ؼ���</param>
		/// <returns>value</returns>
		public static String GetValue(String game,String key)
		{
			System.Collections.IDictionary LanguageConfig = (System.Collections.IDictionary)
				System.Configuration.ConfigurationSettings.GetConfig(game);
			if (LanguageConfig == null)
				return game + " IS Not Exist In This GMTools";
			return LanguageConfig[key].ToString();
		}
		
		#region MainFrame
		public static String ServerSocket_Handler_User = GetValue("MainFrame","ServerSocket_Handler_User");
		public static String ServerSocket_Handler_UserLeft = GetValue("MainFrame","ServerSocket_Handler_UserLeft");
		public static String ServerSocket_ServerSocket_GMTools_Title = GetValue("MainFrame","ServerSocket_ServerSocket_GMTools_Title");
		public static String ServerSocket_ServerSocket_GMTools_Port = GetValue("MainFrame","ServerSocket_ServerSocket_GMTools_Port");
		public static String ServerSocket_ServerSocket_GMTools_Accept = GetValue("MainFrame","ServerSocket_ServerSocket_GMTools_Accept");
		public static String ServerSocket_ServerSocket_GMTools_Client = GetValue("MainFrame","ServerSocket_ServerSocket_GMTools_Client");
		public static String ServerSocket_ServerSocket_GMTools_Validate = GetValue("MainFrame","ServerSocket_ServerSocket_GMTools_Validate");
		public static String ServerSocket_Task_Continue = GetValue("MainFrame","ServerSocket_Task_Continue");
		public static String ServerSocket_Task_Query = GetValue("MainFrame","ServerSocket_Task_Query");
		public static String ServerSocket_UpdatePatch_Error = GetValue("MainFrame","ServerSocket_UpdatePatch_Error");
		#endregion 

		#region Common
		public static String Logic_Exception_Parameter = GetValue("Common","Logic_Exception_Parameter");
		public static String Logic_Exception_ExpectedType = GetValue("Common","Logic_Exception_ExpectedType");
		public static String Logic_Exception_RealType = GetValue("Common","Logic_Exception_RealType");
		public static String Logic_Exception_ExpectedValue = GetValue("Common","Logic_Exception_ExpectedValue");
		public static String Logic_Exception_RealValue = GetValue("Common","Logic_Exception_RealValue");
		public static String Logic_Exception_Error = GetValue("Common","Logic_Exception_Error");
		public static String Logic_TLV_Structure_NumLength = GetValue("Common","Logic_TLV_Structure_NumLength");
		public static String Logic_TLV_Structure_TagFormatType = GetValue("Common","Logic_TLV_Structure_TagFormatType");
		public static String Logic_UserValidate_User = GetValue("Common","Logic_UserValidate_User");
		public static String Logic_UserValidate_AcceptData = GetValue("Common","Logic_UserValidate_AcceptData");
		public static String Logic_UserValidate_ValidateFailue = GetValue("Common","Logic_UserValidate_ValidateFailue");
		public static String Logic_UserValidate_LoggingFailue = GetValue("Common","Logic_UserValidate_LoggingFailue");
		public static String API_Add = GetValue("Common","API_Add");
		public static String API_Delete = GetValue("Common","API_Delete");
		public static String API_Update = GetValue("Common","API_Update");
		public static String API_Success = GetValue("Common","API_Success");
		public static String API_Failure = GetValue("Common","API_Failure");
		public static String API_Display = GetValue("Common","API_Display");
		public static String API_Description = GetValue("Common","API_Description");
		public static String API_CommonAPI_NewServer = GetValue("Common","API_CommonAPI_NewServer");
		public static String API_CommonAPI_GameID = GetValue("Common","API_CommonAPI_GameID");
		public static String API_CommonAPI_ServerIP = GetValue("Common","API_CommonAPI_ServerIP");
		public static String API_CommonAPI_GameCity = GetValue("Common","API_CommonAPI_GameCity");
		public static String API_CommonAPI_GameListEmpty = GetValue("Common","API_CommonAPI_GameListEmpty");
		public static String API_CommonAPI_NoLog = GetValue("Common","API_CommonAPI_NoLog");
		public static String API_DepartmentAPI_DepInfo = GetValue("Common","API_DepartmentAPI_DepInfo");
		public static String API_DepartmentAPI_NoDepInfo = GetValue("Common","API_DepartmentAPI_NoDepInfo");
		public static String API_DepartmentAPI_OperatorID = GetValue("Common","API_DepartmentAPI_OperatorID");
		public static String API_DepartmentAPI_DepID = GetValue("Common","API_DepartmentAPI_DepID");
		public static String API_DepartmentAPI_DepTitle = GetValue("Common","API_DepartmentAPI_DepTitle");
		public static String API_DepartmentAPI_DepDesp = GetValue("Common","API_DepartmentAPI_DepDesp");
		public static String API_DepartmentAPI_GameList = GetValue("Common","API_DepartmentAPI_GameList");
		public static String API_DepartmentAPI_HoldGame = GetValue("Common","API_DepartmentAPI_HoldGame");
		public static String API_GameInfoAPI_GameList = GetValue("Common","API_GameInfoAPI_GameList");
		public static String API_GameInfoAPI_GameID = GetValue("Common","API_GameInfoAPI_GameID");
		public static String API_GameInfoAPI_GameTitle = GetValue("Common","API_GameInfoAPI_GameTitle");
		public static String API_GameInfoAPI_GameDesp = GetValue("Common","API_GameInfoAPI_GameDesp");
		public static String API_GameInfoAPI_GameInfo = GetValue("Common","API_GameInfoAPI_GameInfo");
		public static String API_GameInfoAPI_ModuleID = GetValue("Common","API_GameInfoAPI_ModuleID");
		public static String API_GameInfoAPI_ModuleTitle = GetValue("Common","API_GameInfoAPI_ModuleTitle");
		public static String API_GameInfoAPI_ModuleDesp = GetValue("Common","API_GameInfoAPI_ModuleDesp");
		public static String API_GameInfoAPI_ModuleClass = GetValue("Common","API_GameInfoAPI_ModuleClass");
		public static String API_GameInfoAPI_GameModuleList = GetValue("Common","API_GameInfoAPI_GameModuleList");
		public static String API_ModuleInfoAPI_ModuleInfo = GetValue("Common","API_ModuleInfoAPI_ModuleInfo");
		public static String API_ModuleInfoAPI_NoModuleInfo = GetValue("Common","API_ModuleInfoAPI_NoModuleInfo");
		public static String API_ModuleInfoAPI_ModuleList = GetValue("Common","API_ModuleInfoAPI_ModuleList");
		public static String API_ModuleInfoAPI_NoModuleList = GetValue("Common","API_ModuleInfoAPI_NoModuleList");
		public static String API_NotesInfoAPI_NotesEmailList = GetValue("Common","API_NotesInfoAPI_NotesEmailList");
		public static String API_NotesInfoAPI_NotesTransEmailList = GetValue("Common","API_NotesInfoAPI_NotesTransEmailList");
		public static String API_NotesInfoAPI_EmailID = GetValue("Common","API_NotesInfoAPI_EmailID");
		public static String API_NotesInfoAPI_EmailSubject = GetValue("Common","API_NotesInfoAPI_EmailSubject");
		public static String API_NotesInfoAPI_EmailContent = GetValue("Common","API_NotesInfoAPI_EmailContent");
		public static String API_NotesInfoAPI_EmailSender = GetValue("Common","API_NotesInfoAPI_EmailSender");
		public static String API_NotesInfoAPI_NoDealWithEmail = GetValue("Common","API_NotesInfoAPI_NoDealWithEmail");
		public static String API_NotesInfoAPI_NoTransDealWithEmail = GetValue("Common","API_NotesInfoAPI_NoTransDealWithEmail");
		public static String API_NotesInfoAPI_DealWithEmailFailure = GetValue("Common","API_NotesInfoAPI_DealWithEmailFailure");
		public static String API_UserInfoAPI_NoUserList = GetValue("Common","API_UserInfoAPI_NoUserList");
		public static String API_UserInfoAPI_AccountInfo = GetValue("Common","API_UserInfoAPI_AccountInfo");
		public static String API_UserInfoAPI_Password = GetValue("Common","API_UserInfoAPI_Password");
		public static String API_UserInfoAPI_NewPassword = GetValue("Common","API_UserInfoAPI_NewPassword");
		public static String API_UserInfoAPI_MAC = GetValue("Common","API_UserInfoAPI_MAC");
		public static String API_UserInfoAPI_NoAdmin = GetValue("Common","API_UserInfoAPI_NoAdmin");
		public static String API_UserInfoAPI_UserStatus = GetValue("Common","API_UserInfoAPI_UserStatus");
		public static String API_UserInfoAPI_LimitDay = GetValue("Common","API_UserInfoAPI_LimitDay");
		public static String API_UserInfoAPI_UserID = GetValue("Common","API_UserInfoAPI_UserID");
		public static String API_UserModuleAPI_NoRecord = GetValue("Common","API_UserModuleAPI_NoRecord");
		public static String API_UserModuleAPI_UserAuth = GetValue("Common","API_UserModuleAPI_UserAuth");
		public static String API_UserModuleAPI_UserModule = GetValue("Common","API_UserModuleAPI_UserModule");
		#endregion

		#region SDO
		public static String SDOAPI_SDO = GetValue("SDO","SDOAPI_SDO");
		public static String SDOAPI_SDOChallengeDataAPI_Challenge = GetValue("SDO","SDOAPI_SDOChallengeDataAPI_Challenge");
		public static String SDOAPI_SDOChallengeDataAPI_Scene = GetValue("SDO","SDOAPI_SDOChallengeDataAPI_Scene");
		public static String SDOAPI_SDOChallengeDataAPI_SceneProbability = GetValue("SDO","SDOAPI_SDOChallengeDataAPI_SceneProbability");
		public static String SDOAPI_SDOChallengeDataAPI_GameMusicList = GetValue("SDO","SDOAPI_SDOChallengeDataAPI_GameMusicList");
		public static String SDOAPI_SDOChallengeDataAPI_ProbabilityList = GetValue("SDO","SDOAPI_SDOChallengeDataAPI_ProbabilityList");
		public static String SDOAPI_SDOChallengeDataAPI_NoChallengeScene = GetValue("SDO","SDOAPI_SDOChallengeDataAPI_NoChallengeScene");
		public static String SDOAPI_SDOChallengeDataAPI_NoGameMusicList = GetValue("SDO","SDOAPI_SDOChallengeDataAPI_NoGameMusicList");
		public static String SDOAPI_SDOChallengeDataAPI_NoSceneList = GetValue("SDO","SDOAPI_SDOChallengeDataAPI_NoSceneList");
		public static String SDOAPI_SDOChallengeDataAPI_NoProbabilityList = GetValue("SDO","SDOAPI_SDOChallengeDataAPI_NoProbabilityList");
		public static String SDOAPI_SDOCharacterInfoAPI_NoAccount = GetValue("SDO","SDOAPI_SDOCharacterInfoAPI_NoAccount");
		public static String SDOAPI_SDOCharacterInfoAPI_AccountInfo = GetValue("SDO","SDOAPI_SDOCharacterInfoAPI_AccountInfo");
		public static String SDOAPI_SDOCharacterInfoAPI_NoRelativeInfo = GetValue("SDO","SDOAPI_SDOCharacterInfoAPI_NoRelativeInfo");
		public static String SDOAPI_SDOItemLogInfoAPI_Account = GetValue("SDO","SDOAPI_SDOItemLogInfoAPI_Account");
		public static String SDOAPI_SDOItemLogInfoAPI_FillDetail = GetValue("SDO","SDOAPI_SDOItemLogInfoAPI_FillDetail");
		public static String SDOAPI_SDOItemLogInfoAPI_Sum = GetValue("SDO","SDOAPI_SDOItemLogInfoAPI_Sum");
		public static String SDOAPI_SDOItemLogInfoAPI_GCash = GetValue("SDO","SDOAPI_SDOItemLogInfoAPI_GCash");
		public static String SDOAPI_SDOItemLogInfoAPI_Compensate = GetValue("SDO","SDOAPI_SDOItemLogInfoAPI_Compensate");
		public static String SDOAPI_SDOItemLogInfoAPI_NoChargeRecord = GetValue("SDO","SDOAPI_SDOItemLogInfoAPI_NoChargeRecord");
		public static String SDOAPI_SDOItemLogInfoAPI_NoTotalValue = GetValue("SDO","SDOAPI_SDOItemLogInfoAPI_NoTotalValue");
		public static String SDOAPI_SDOItemShopAPI_GameItem = GetValue("SDO","SDOAPI_SDOItemShopAPI_GameItem");
		public static String SDOAPI_SDOItemShopAPI_PersonalItem = GetValue("SDO","SDOAPI_SDOItemShopAPI_PersonalItem");
		public static String SDOAPI_SDOItemShopAPI_GiftItem = GetValue("SDO","SDOAPI_SDOItemShopAPI_GiftItem");
		public static String SDOAPI_SDOItemShopAPI_OnlineStatus = GetValue("SDO","SDOAPI_SDOItemShopAPI_OnlineStatus");
		public static String SDOAPI_SDOItemShopAPI_ConsumeRecord = GetValue("SDO","SDOAPI_SDOItemShopAPI_ConsumeRecord");
		public static String SDOAPI_SDOItemShopAPI_TradeRecord = GetValue("SDO","SDOAPI_SDOItemShopAPI_TradeRecord");
		public static String SDOAPI_SDOItemShopAPI_NoItem = GetValue("SDO","SDOAPI_SDOItemShopAPI_NoItem");
		public static String SDOAPI_SDOItemShopAPI_NoItemOnPlayer = GetValue("SDO","SDOAPI_SDOItemShopAPI_NoItemOnPlayer");
		public static String SDOAPI_SDOItemShopAPI_NoItemOnGift = GetValue("SDO","SDOAPI_SDOItemShopAPI_NoItemOnGift");
		public static String SDOAPI_SDOItemShopAPI_NoOnlineStatus = GetValue("SDO","SDOAPI_SDOItemShopAPI_NoOnlineStatus");
		public static String SDOAPI_SDOItemShopAPI_NoItemLimit = GetValue("SDO","SDOAPI_SDOItemShopAPI_NoItemLimit");
		public static String SDOAPI_SDOItemShopAPI_NoChargeRecord = GetValue("SDO","SDOAPI_SDOItemShopAPI_NoChargeRecord");
		public static String SDOAPI_SDOItemShopAPI_NoTradeRecord = GetValue("SDO","SDOAPI_SDOItemShopAPI_NoTradeRecord");
		public static String SDOAPI_SDOMemberInfoAPI_ActiveState = GetValue("SDO","SDOAPI_SDOMemberInfoAPI_ActiveState");
		public static String SDOAPI_SDOMemberInfoAPI_NoActived = GetValue("SDO","SDOAPI_SDOMemberInfoAPI_NoActived");
		public static String SDOAPI_SDOMemberInfoAPI_AllBanAccount = GetValue("SDO","SDOAPI_SDOMemberInfoAPI_AllBanAccount");
		public static String SDOAPI_SDOMemberInfoAPI_NoBanAccount = GetValue("SDO","SDOAPI_SDOMemberInfoAPI_NoBanAccount");
		public static String SDOAPI_SDOMemberInfoAPI_BanInfo = GetValue("SDO","SDOAPI_SDOMemberInfoAPI_BanInfo");
		public static String SDOAPI_SDOMemberInfoAPI_NoBanInfo = GetValue("SDO","SDOAPI_SDOMemberInfoAPI_NoBanInfo");
		public static String SDOAPI_SDOMemberInfoAPI_AccountUnlock = GetValue("SDO","SDOAPI_SDOMemberInfoAPI_AccountUnlock");
		public static String SDOAPI_SDOMemberInfoAPI_AccountLock = GetValue("SDO","SDOAPI_SDOMemberInfoAPI_AccountLock");
		public static String SDOAPI_SDOMemberInfoAPI_NoCurrentInfo = GetValue("SDO","SDOAPI_SDOMemberInfoAPI_NoCurrentInfo");
		public static String SDOAPI_SDOMemberInfoAPI_CurrentState = GetValue("SDO","SDOAPI_SDOMemberInfoAPI_CurrentState");
		public static String SDOAPI_SDONoticeInfoAPI_SendNoticeInfo = GetValue("SDO","SDOAPI_SDONoticeInfoAPI_SendNoticeInfo");
		public static String SDOAPI_SDONoticeInfoAPI_SendNoticeList = GetValue("SDO","SDOAPI_SDONoticeInfoAPI_SendNoticeList");
		public static String SDOAPI_SDONoticeInfoAPI_NoNoticeList = GetValue("SDO","SDOAPI_SDONoticeInfoAPI_NoNoticeList");
		public static String SDOAPI_SDONoticeInfoAPI_ChannelList = GetValue("SDO","SDOAPI_SDONoticeInfoAPI_ChannelList");
		public static String SDOAPI_SDONoticeInfoAPI_NoChannelInfo = GetValue("SDO","SDOAPI_SDONoticeInfoAPI_NoChannelInfo");
		public static String SDOAPI_SDONoticeInfoAPI_LoginFailure = GetValue("SDO","SDOAPI_SDONoticeInfoAPI_LoginFailure");
		public static String SDOAPI_SDOCharacterInfoAPI_FriendList = GetValue("SDO","SDOAPI_SDOCharacterInfoAPI_FriendList");
		public static String SDOAPI_SDOCharacterInfoAPI_NoFriendList = GetValue("SDO","SDOAPI_SDOCharacterInfoAPI_NoFriendList");
		public static String SDOAPI_SDOCharacterInfoAPI_NotOnline = GetValue("SDO","SDOAPI_SDOCharacterInfoAPI_NotOnline");
		public static String SDOAPI_SDOCharacterInfoAPI_KickSuccess = GetValue("SDO","SDOAPI_SDOCharacterInfoAPI_KickSuccess");
		public static String SDOAPI_SDOCharacterInfoAPI_KickFailure = GetValue("SDO","SDOAPI_SDOCharacterInfoAPI_KickFailure");
		public static String SDOAPI_SDOCharacterInfoAPI_GateWay = GetValue("SDO","SDOAPI_SDOCharacterInfoAPI_GateWay");
		public static String SDOAPI_SDOItemShopAPI_Integral = GetValue("SDO","SDOAPI_SDOItemShopAPI_Integral");
		public static String SDOAPI_SDOItemShopAPI_NoIntegral = GetValue("SDO","SDOAPI_SDOItemShopAPI_NoIntegral");
		
		public static String SDOAPI_SDOItemMsG = GetValue("SDO","SDOAPI_SDOItemMsG");
		public static String SDOAPI_SDOItemMsG1 = GetValue("SDO","SDOAPI_SDOItemMsG1");
		public static String SDOAPI_SDOItemMsG2 = GetValue("SDO","SDOAPI_SDOItemMsG2");
		public static String SDOAPI_SDOItemMsG3 = GetValue("SDO","SDOAPI_SDOItemMsG3");

		public static String SDOAPI_SDOItemMsG4 = GetValue("SDO","SDOAPI_SDOItemMsG4");
		public static String SDOAPI_SDOItemMsG5 = GetValue("SDO","SDOAPI_SDOItemMsG5");
		public static String SDOAPI_SDOItemMsG6 = GetValue("SDO","SDOAPI_SDOItemMsG6");
		public static String SDOAPI_SDOItemMsG7 = GetValue("SDO","SDOAPI_SDOItemMsG7");
		public static String SDOAPI_SDOItemMsG8 = GetValue("SDO","SDOAPI_SDOItemMsG8");
		public static String SDOAPI_SDOItemMsG9 = GetValue("SDO","SDOAPI_SDOItemMsG9");

		#endregion
	}
}
