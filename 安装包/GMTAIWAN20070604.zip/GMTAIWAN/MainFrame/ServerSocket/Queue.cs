using System;

namespace GMSERVER.ServerSocket
{
	/// <summary>
	/// Queue ��ժҪ˵����
	/// </summary>
	public class Queue:System.Collections.Queue
	{
		public Queue()
		{
			//
			// TODO: �ڴ˴����ӹ��캯���߼�
			//
		}
		public int initized()
		{
			return -1;;

		}
		private void process()
		{

		}
		public int finalize()
		{
			return 0;

		}
	}
}
