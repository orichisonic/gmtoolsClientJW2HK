using System;
using System.Data;
using System.Data.SqlClient;
using Common.Logic;
using Common.DataInfo;

namespace SDO.SDODataInfo
{
	/// <summary>
	/// ChallengeDataInfo ��ժҪ˵����
	/// </summary>
	public class ChallengeDataInfo
	{
		public ChallengeDataInfo()
		{
			//
			// TODO: �ڴ˴����ӹ��캯���߼�
			//
		}
		#region �鿴��Ϸ���泡���б�
		/// <summary>
		/// �鿴��Ϸ���泡���б�
		/// </summary>
		/// <param name="serverIP">������IP</param>
		/// <returns>�������ݼ�</returns>
		public static DataSet TO2JAM_Challenge_Query(string serverIP)
		{
			DataSet result = null;
			SqlParameter[] paramCode;
			try
			{
				paramCode = new SqlParameter[1]{
												   new SqlParameter("@SDO_serverip",SqlDbType.VarChar,30)};
				paramCode[0].Value=serverIP;
				result = SqlHelper.ExecSPDataSet("SDO_TO2JAM_Challenge_Query",paramCode);
			}
			catch(SqlException ex)
			{
				Console.WriteLine(ex.Message);
			}
			return result;
		}
		#endregion
		#region �鿴��Ϸ���������б�
		/// <summary>
		/// �鿴��Ϸ���������б�
		/// </summary>
		/// <param name="serverIP">������IP</param>
		/// <returns>�������ݼ�</returns>
		public static DataSet TO2JAM_MusicData_Query(string serverIP)
		{
			DataSet result = null;
			SqlParameter[] paramCode;
			try
			{
				paramCode = new SqlParameter[1]{
												   new SqlParameter("@SDO_serverip",SqlDbType.VarChar,30)};
				paramCode[0].Value=serverIP;
				result = SqlHelper.ExecSPDataSet("SDO_TO2JAM_MusicData_Query",paramCode);
			}
			catch(SqlException ex)
			{
				Console.WriteLine(ex.Message);
			}
			return result;
		}
		#endregion
		#region ����ID�鿴��Ϸ���������б�
		/// <summary>
		/// ����ID�鿴��Ϸ���������б�
		/// </summary>
		/// <param name="serverIP">������IP</param>
		/// <returns>�������ݼ�</returns>
		public static DataSet TO2JAM_MusicData_Query(string serverIP,int musicID)
		{
			DataSet result = null;
			SqlParameter[] paramCode;
			try
			{
				paramCode = new SqlParameter[2]{
												   new SqlParameter("@SDO_serverip",SqlDbType.VarChar,30),
												   new SqlParameter("@SDO_MusicID",SqlDbType.Int)};
				paramCode[0].Value =serverIP;
				paramCode[1].Value = musicID;
				result = SqlHelper.ExecSPDataSet("SDO_TO2JAM_MusicData_SingleQuery",paramCode);
			}
			catch(SqlException ex)
			{
				Console.WriteLine(ex.Message);
			}
			return result;
		}
		#endregion
		#region �鿴��Ϸ���泡���б�
		/// <summary>
		/// �鿴��Ϸ���泡���б�
		/// </summary>
		/// <param name="serverIP">������IP</param>
		/// <returns>�������ݼ�</returns>
		public static DataSet TO2JAM_SceneListQuery()
		{
			DataSet result = null;
			try
			{
				result = SqlHelper.ExecSPDataSet("SDO_TO2JAM_Scene_Query");
			}
			catch(SqlException ex)
			{
				Console.WriteLine(ex.Message);
			}
			return result;
		}
		#endregion
		#region ������Ϸ���泡���б�
		/// <summary>
		/// ������Ϸ���泡��
		/// </summary>
		/// <param name="serverIP">������IP</param>
		/// <returns>�������ݼ�</returns>
		public static int TO2JAM_ChallengeScene_Insert(int GMUserID,int sceneID,string sceneTag)
		{
			int result = -1;
			SqlParameter[] paramCode;
			try
			{
				paramCode = new SqlParameter[4]{
													new SqlParameter("@Gm_UserID",SqlDbType.VarChar,20),
													new SqlParameter("@SDO_SceneID",SqlDbType.Int),
													new SqlParameter("@SDO_SceneTag",SqlDbType.VarChar,400),
													new SqlParameter("@result",SqlDbType.Int)};
				paramCode[0].Value=GMUserID;
				paramCode[1].Value=sceneID;
				paramCode[2].Value=sceneTag;
				paramCode[3].Direction = ParameterDirection.ReturnValue;
				result = SqlHelper.ExecSPCommand("SDO_TO2JAM_Scene_Insert",paramCode);
				if(GMUserID == 0)
				{
					CommonInfo.SDO_OperatorLogDel(GMUserID);
				}
			}
			catch(SqlException ex)
			{
				Console.WriteLine(ex.Message);
			}
			return result;
		}
		#endregion
		#region ������Ϸ���泡���б�
		/// <summary>
		/// ������Ϸ���泡��
		/// </summary>
		/// <returns>�������ݼ�</returns>
		public static int TO2JAM_ChallengeScene_Update(int GMUserID,int sceneID,string sceneTag)
		{
			int result = -1;
			SqlParameter[] paramCode;
			try
			{
				paramCode = new SqlParameter[4]{
												   new SqlParameter("@Gm_UserID",SqlDbType.VarChar,20),
												   new SqlParameter("@SDO_SceneID",SqlDbType.Int),
												   new SqlParameter("@SDO_SceneTag",SqlDbType.VarChar,400),
												   new SqlParameter("@result",SqlDbType.Int)};
				paramCode[0].Value=GMUserID;
				paramCode[1].Value=sceneID;
				paramCode[2].Value=sceneTag;
				paramCode[3].Direction = ParameterDirection.ReturnValue;
				result = SqlHelper.ExecSPCommand("SDO_TO2JAM_Scene_Update",paramCode);
				if(GMUserID == 0)
				{
					CommonInfo.SDO_OperatorLogDel(GMUserID);
				}
			}
			catch(SqlException ex)
			{
				Console.WriteLine(ex.Message);
			}
			return result;
		}
		#endregion
		#region ɾ����Ϸ���泡���б�
		/// <summary>
		/// ɾ����Ϸ���泡��
		/// </summary>
		/// <returns>�������ݼ�</returns>
		public static int TO2JAM_ChallengeScene_Delete(int GMUserID,int sceneID)
		{
			int result = -1;
			SqlParameter[] paramCode;
			try
			{
				paramCode = new SqlParameter[3]{
												   new SqlParameter("@Gm_UserID",SqlDbType.VarChar,20),
												   new SqlParameter("@SDO_SceneID",SqlDbType.Int),
												   new SqlParameter("@result",SqlDbType.Int)};
				paramCode[0].Value=GMUserID;
				paramCode[1].Value=sceneID;
				paramCode[2].Direction = ParameterDirection.ReturnValue;
				result = SqlHelper.ExecSPCommand("SDO_TO2JAM_Scene_Delete",paramCode);
				if(GMUserID == 0)
				{
					CommonInfo.SDO_OperatorLogDel(GMUserID);
				}
			}
			catch(SqlException ex)
			{
				Console.WriteLine(ex.Message);
			}
			return result;
		}
		#endregion
		#region �鿴�����л�õ��߸����б�
		/// <summary>
		/// �鿴�����л�õ��߸����б�
		/// </summary>
		/// <param name="serverIP">������IP</param>
		/// <returns>�������ݼ�</returns>
		public static DataSet TO2JAM_Medalitem_Query(string serverIP)
		{
			DataSet result = null;
			SqlParameter[] paramCode;
			try
			{
				paramCode = new SqlParameter[1]{
												   new SqlParameter("@SDO_serverip",SqlDbType.VarChar,30)};
				paramCode[0].Value=serverIP;
				result = SqlHelper.ExecSPDataSet("SDO_TO2JAM_Medalitem_Query",paramCode);
			}
			catch(SqlException ex)
			{
				Console.WriteLine(ex.Message);
			}
			return result;
		}
		#endregion
		#region ���ݵ������鿴�����л�õ��߸����б�
		/// <summary>
		/// ���ݵ������鿴�����л�õ��߸����б�
		/// </summary>
		/// <param name="serverIP">������IP</param>
		/// <returns>�������ݼ�</returns>
		public static DataSet TO2JAM_Medalitem_Owner_Query(string serverIP,string itemName)
		{
			DataSet result = null;
			SqlParameter[] paramCode;
			try
			{
				paramCode = new SqlParameter[2]{
												   new SqlParameter("@SDO_serverip",SqlDbType.VarChar,30),
												   new SqlParameter("@SDO_Name",SqlDbType.VarChar,50)};
				paramCode[0].Value=serverIP;
				paramCode[1].Value=itemName;
				result = SqlHelper.ExecSPDataSet("SDO_TO2JAM_Medalitem_Own_Query",paramCode);
			}
			catch(SqlException ex)
			{
				Console.WriteLine(ex.Message);
			}
			return result;
		}
		#endregion
		#region �����ڳ�����ø���
		/// <summary>
		/// �����ڳ�����ø���
		/// </summary>
		/// <param name="serverIP">������IP</param>
		/// <returns>�������ݼ�</returns>
		public static int TO2JAM_Medalitem_Insert(int GMUserID,string serverIP,int itemcode,int percent,int timeslimit,int dayslimit)
		{
			int result = -1;
			SqlParameter[] paramCode;
			try
			{
				paramCode = new SqlParameter[7]{
												   new SqlParameter("@Gm_UserID",SqlDbType.VarChar,20),
												   new SqlParameter("@SDO_ServerIP",SqlDbType.VarChar,30),
												   new SqlParameter("@SDO_ItemCode",SqlDbType.Int),
												   new SqlParameter("@SDO_Percent",SqlDbType.Int),
												   new SqlParameter("@SDO_timeslimit",SqlDbType.Int),
												   new SqlParameter("@SDO_DaysLimit",SqlDbType.Int),
												   new SqlParameter("@result",SqlDbType.Int)};
				paramCode[0].Value=GMUserID;
				paramCode[1].Value=serverIP;
				paramCode[2].Value=itemcode;
				paramCode[3].Value=percent;
				paramCode[4].Value=timeslimit;
				paramCode[5].Value=dayslimit;
				paramCode[6].Direction = ParameterDirection.ReturnValue;
				result = SqlHelper.ExecSPCommand("SDO_TO2JAM_Medalitem_Insert",paramCode);
				if(GMUserID == 0)
				{
					CommonInfo.SDO_OperatorLogDel(GMUserID);
				}
			}
			catch(SqlException ex)
			{
				Console.WriteLine(ex.Message);
			}
			return result;
		}
		#endregion
		#region �����ڳ�����ø���
		/// <summary>
		/// �����ڳ�����ø���
		/// </summary>
		/// <returns>�������ݼ�</returns>
		public static int TO2JAM_Medalitem_Update(int GMUserID,string serverIP,int itemcode,int percent,int timeslimit,int dayslimit)
		{
			int result = -1;
			SqlParameter[] paramCode;
			try
			{
				paramCode = new SqlParameter[7]{
												   new SqlParameter("@Gm_UserID",SqlDbType.VarChar,20),
												   new SqlParameter("@SDO_ServerIP",SqlDbType.VarChar,30),
												   new SqlParameter("@SDO_ItemCode",SqlDbType.Int),
												   new SqlParameter("@SDO_Percent",SqlDbType.Int),
												   new SqlParameter("@SDO_timeslimit",SqlDbType.Int),
												   new SqlParameter("@SDO_DaysLimit",SqlDbType.Int),
												   new SqlParameter("@result",SqlDbType.Int)};
				paramCode[0].Value=GMUserID;
				paramCode[1].Value=serverIP;
				paramCode[2].Value=itemcode;
				paramCode[3].Value=percent;
				paramCode[4].Value=timeslimit;
				paramCode[5].Value=dayslimit;
				paramCode[6].Direction = ParameterDirection.ReturnValue;
				result = SqlHelper.ExecSPCommand("SDO_TO2JAM_Medalitem_Update",paramCode);
				if(GMUserID == 0)
				{
					CommonInfo.SDO_OperatorLogDel(GMUserID);
				}
			}
			catch(SqlException ex)
			{
				Console.WriteLine(ex.Message);
			}
			return result;
		}
		#endregion
		#region ɾ���ڳ�����ø���
		/// <summary>
		/// ɾ���ڳ�����ø���
		/// </summary>
		/// <returns>�������ݼ�</returns>
		public static int TO2JAM_Medalitem_Delete(int GMUserID,string serverIP,int itemcode)
		{
			int result = -1;
			SqlParameter[] paramCode;
			try
			{
				paramCode = new SqlParameter[4]{
												   new SqlParameter("@Gm_UserID",SqlDbType.VarChar,20),
												   new SqlParameter("@SDO_ServerIP",SqlDbType.VarChar,30),
												   new SqlParameter("@SDO_ItemCode",SqlDbType.Int),
												   new SqlParameter("@result",SqlDbType.Int)};
				paramCode[0].Value=GMUserID;
				paramCode[1].Value=serverIP;
				paramCode[2].Value=itemcode;
				paramCode[3].Direction = ParameterDirection.ReturnValue;
				result = SqlHelper.ExecSPCommand("SDO_TO2JAM_Medalitem_Delete",paramCode);
				if(GMUserID == 0)
				{
					CommonInfo.SDO_OperatorLogDel(GMUserID);
				}
			}
			catch(SqlException ex)
			{
				Console.WriteLine(ex.Message);
			}
			return result;
		}
		#endregion
		#region ������Ϸ���泡��
		/// <summary>
		/// ������Ϸ���泡��
		/// </summary>
		/// <param name="serverIP">������IP</param>
		/// <returns>�������ݼ�</returns>
		public static int TO2JAM_Challenge_Insert(int GMUserID,string serverIP,int WeekDay,int MatPt_hr,int MatPt_min,int StPt_hr,int StPt_min,int EdPt_hr,int EdPt_min,int GCash,int MCash,int Scene,int musicID1,int lv1,int musicID2,int lv2,int musicID3,int lv3,int musicID4,int lv4,int musicID5,int lv5)
		{
			int result = -1;
			SqlParameter[] paramCode;
			try
			{
				paramCode = new SqlParameter[23]{
													new SqlParameter("@Gm_UserID",SqlDbType.VarChar,20),
													new SqlParameter("@SDO_serverip",SqlDbType.VarChar,30),
													new SqlParameter("@SDO_WeekDay",SqlDbType.Int),
													new SqlParameter("@SDO_MatPtHR",SqlDbType.Int),
													new SqlParameter("@SDO_MatPtMin",SqlDbType.Int),
													new SqlParameter("@SDO_StPtHR",SqlDbType.Int),
													new SqlParameter("@SDO_StPtMin",SqlDbType.Int),
													new SqlParameter("@SDO_EdPtHR",SqlDbType.Int),
													new SqlParameter("@SDO_EdPtMin",SqlDbType.Int),
													new SqlParameter("@SDO_GCash",SqlDbType.Int),
													new SqlParameter("@SDO_MCash",SqlDbType.Int),
													new SqlParameter("@SDO_Sence",SqlDbType.Int),
													new SqlParameter("@SDO_MusicID1",SqlDbType.Int),
													new SqlParameter("@SDO_LV1",SqlDbType.Int),
													new SqlParameter("@SDO_MusicID2",SqlDbType.Int),
													new SqlParameter("@SDO_LV2",SqlDbType.Int),
													new SqlParameter("@SDO_MusicID3",SqlDbType.Int),
													new SqlParameter("@SDO_LV3",SqlDbType.Int),
													new SqlParameter("@SDO_MusicID4",SqlDbType.Int),
													new SqlParameter("@SDO_LV4",SqlDbType.Int),
													new SqlParameter("@SDO_MusicID5",SqlDbType.Int),
													new SqlParameter("@SDO_LV5",SqlDbType.Int),
				                                    new SqlParameter("@result",SqlDbType.Int)};
				paramCode[0].Value=GMUserID;
				paramCode[1].Value=serverIP;
				paramCode[2].Value=WeekDay;
				paramCode[3].Value=MatPt_hr;
				paramCode[4].Value=MatPt_min;
				paramCode[5].Value=StPt_hr;
				paramCode[6].Value=StPt_min;
				paramCode[7].Value=EdPt_hr;
				paramCode[8].Value=EdPt_min;
				paramCode[9].Value=GCash;
				paramCode[10].Value=MCash;
				paramCode[11].Value=Scene;
				paramCode[12].Value=musicID1;
				paramCode[13].Value=lv1;
				paramCode[14].Value=musicID2;
				paramCode[15].Value=lv2;
				paramCode[16].Value=musicID3;
				paramCode[17].Value=lv3;
				paramCode[18].Value=musicID4;
				paramCode[19].Value=lv4;
				paramCode[20].Value=musicID5;
				paramCode[21].Value=lv5;
				paramCode[22].Direction = ParameterDirection.ReturnValue;
				result = SqlHelper.ExecSPCommand("SDO_TO2JAM_Challenge_Insert",paramCode);
				if(GMUserID == 0)
				{
					CommonInfo.SDO_OperatorLogDel(GMUserID);
				}
			}
			catch(SqlException ex)
			{
				Console.WriteLine(ex.Message);
			}
			return result;
		}
		#endregion
		#region ������Ϸ���泡��
		/// <summary>
		/// ������Ϸ���泡��
		/// </summary>
		/// <param name="serverIP">������IP</param>
		/// <returns>�������ݼ�</returns>
		public static int TO2JAM_Challenge_Update(int GMUserID,string serverIP,int sceneID,int WeekDay,int MatPt_hr,int MatPt_min,int StPt_hr,int StPt_min,int EdPt_hr,int EdPt_min,int GCash,int MCash,int Scene,int musicID1,int lv1,int musicID2,int lv2,int musicID3,int lv3,int musicID4,int lv4,int musicID5,int lv5)
		{
			int result = -1;
			SqlParameter[] paramCode;
			try
			{
				paramCode = new SqlParameter[24]{
													new SqlParameter("@Gm_UserID",SqlDbType.VarChar,20),
													new SqlParameter("@SDO_serverip",SqlDbType.VarChar,30),
													new SqlParameter("@SDO_SceneID",SqlDbType.Int),
													new SqlParameter("@SDO_WeekDay",SqlDbType.Int),
													new SqlParameter("@SDO_MatPtHR",SqlDbType.Int),
													new SqlParameter("@SDO_MatPtMin",SqlDbType.Int),
													new SqlParameter("@SDO_StPtHR",SqlDbType.Int),
													new SqlParameter("@SDO_StPtMin",SqlDbType.Int),
													new SqlParameter("@SDO_EdPtHR",SqlDbType.Int),
													new SqlParameter("@SDO_EdPtMin",SqlDbType.Int),
													new SqlParameter("@SDO_GCash",SqlDbType.Int),
													new SqlParameter("@SDO_MCash",SqlDbType.Int),
													new SqlParameter("@SDO_Sence",SqlDbType.Int),
													new SqlParameter("@SDO_MusicID1",SqlDbType.Int),
													new SqlParameter("@SDO_LV1",SqlDbType.Int),
													new SqlParameter("@SDO_MusicID2",SqlDbType.Int),
													new SqlParameter("@SDO_LV2",SqlDbType.Int),
													new SqlParameter("@SDO_MusicID3",SqlDbType.Int),
													new SqlParameter("@SDO_LV3",SqlDbType.Int),
													new SqlParameter("@SDO_MusicID4",SqlDbType.Int),
													new SqlParameter("@SDO_LV4",SqlDbType.Int),
													new SqlParameter("@SDO_MusicID5",SqlDbType.Int),
													new SqlParameter("@SDO_LV5",SqlDbType.Int),
													new SqlParameter("@result",SqlDbType.Int)};
				paramCode[0].Value=GMUserID;
				paramCode[1].Value=serverIP;
				paramCode[2].Value=sceneID;
				paramCode[3].Value=WeekDay;
				paramCode[4].Value=MatPt_hr;
				paramCode[5].Value=MatPt_min;
				paramCode[6].Value=StPt_hr;
				paramCode[7].Value=StPt_min;
				paramCode[8].Value=EdPt_hr;
				paramCode[9].Value=EdPt_min;
				paramCode[10].Value=GCash;
				paramCode[11].Value=MCash;
				paramCode[12].Value=Scene;
				paramCode[13].Value=musicID1;
				paramCode[14].Value=lv1;
				paramCode[15].Value=musicID2;
				paramCode[16].Value=lv2;
				paramCode[17].Value=musicID3;
				paramCode[18].Value=lv3;
				paramCode[19].Value=musicID4;
				paramCode[20].Value=lv4;
				paramCode[21].Value=musicID5;
				paramCode[22].Value=lv5;
				paramCode[23].Direction = ParameterDirection.ReturnValue;
				result = SqlHelper.ExecSPCommand("SDO_TO2JAM_Challenge_Update",paramCode);
				if(GMUserID == 0)
				{
					CommonInfo.SDO_OperatorLogDel(GMUserID);
				}
			}
			catch(SqlException ex)
			{
				Console.WriteLine(ex.Message);
			}
			return result;
		}
		#endregion
		#region ɾ����Ϸ���泡���б�
		/// <summary>
		/// ɾ����Ϸ���泡���б�
		/// </summary>
		/// <param name="serverIP">������IP</param>
		/// <returns>�������ݼ�</returns>
		public static int TO2JAM_Challenge_Del(string serverIP,int gmUserID,int sceneID)
		{
			int result = -1;
			SqlParameter[] paramCode;
			try
			{
				paramCode = new SqlParameter[4]{
												   new SqlParameter("@Gm_UserID",SqlDbType.VarChar,20),
												   new SqlParameter("@SDO_serverip",SqlDbType.VarChar,30),
												   new SqlParameter("@SDO_SceneID",SqlDbType.Int),
												   new SqlParameter("@result",SqlDbType.Int)};
				paramCode[0].Value=gmUserID;
				paramCode[1].Value=serverIP;
				paramCode[2].Value=sceneID;
				paramCode[3].Direction = ParameterDirection.ReturnValue;
				result = SqlHelper.ExecSPCommand("SDO_TO2JAM_Challenge_Del",paramCode);
				if(gmUserID == 0)
				{
					CommonInfo.SDO_OperatorLogDel(gmUserID);
				}
			} 
			catch(SqlException ex)
			{
				Console.WriteLine(ex.Message);
			}
			return result;
		}
		#endregion

		#region �鿴�����л�õ��߸����б�
		/// <summary>
		/// �鿴����Ϸ��ҡҡ�ֻ�ø���
		/// </summary>
		/// <param name="serverIP">������IP</param>
		/// <returns>�������ݼ�</returns>
		public static DataSet SDO_YYHappy_Query(string serverIP,string itemName)
		{
			DataSet result = null;
			SqlParameter[] paramCode;
			try
			{
				paramCode = new SqlParameter[2]{
												   new SqlParameter("@SDO_serverip",SqlDbType.VarChar,30),
												   new SqlParameter("@SDO_Name",SqlDbType.VarChar,50)};
				paramCode[0].Value=serverIP;
				paramCode[1].Value=itemName;
				result = SqlHelper.ExecSPDataSet("SDO_YYHappyItem_Query",paramCode);
			}
			catch(SqlException ex)
			{
				Console.WriteLine(ex.Message);
			}
			return result;
		}
		#endregion
		#region ����ҡҡ�ֻ�ø���
		/// <summary>
		/// ����ҡҡ�ֻ�ø���
		/// </summary>
		/// <param name="serverIP">������IP</param>
		/// <returns>�������ݼ�</returns>
		public static int SDO_YYHappyitem_Insert(int GMUserID,string serverIP,int itemcode,string itemName,int level,int levPercent,int percent,int timeslimit,int dayslimit)
		{
			int result = -1;
			SqlParameter[] paramCode;
			try
			{
				paramCode = new SqlParameter[10]{
													new SqlParameter("@Gm_UserID",SqlDbType.VarChar,20),
													new SqlParameter("@SDO_ServerIP",SqlDbType.VarChar,30),
													new SqlParameter("@SDO_ItemCode",SqlDbType.Int),
													new SqlParameter("@SDO_ItemName",SqlDbType.VarChar,50),
													new SqlParameter("@SDO_Level",SqlDbType.TinyInt),
													new SqlParameter("@SDO_LevPerc",SqlDbType.Int),
													new SqlParameter("@SDO_Percent",SqlDbType.Int),
													new SqlParameter("@SDO_timeslimit",SqlDbType.Int),
													new SqlParameter("@SDO_DaysLimit",SqlDbType.Int),
													new SqlParameter("@result",SqlDbType.Int)};
				paramCode[0].Value=GMUserID;
				paramCode[1].Value=serverIP;
				paramCode[2].Value=itemcode;
				paramCode[3].Value=itemName;
				paramCode[4].Value=level;
				paramCode[5].Value=levPercent;
				paramCode[6].Value=percent;
				paramCode[7].Value=timeslimit;
				paramCode[8].Value=dayslimit;
				paramCode[9].Direction = ParameterDirection.ReturnValue;
				result = SqlHelper.ExecSPCommand("SDO_YYHappyItem_Insert",paramCode);
			}
			catch(SqlException ex)
			{
				Console.WriteLine(ex.Message);
			}
			return result;
		}
		#endregion
		#region ����ҡҡ�ֻ�ø���
		/// <summary>
		/// ����ҡҡ�ֻ�ø���
		/// </summary>
		/// <returns>�������ݼ�</returns>
		public static int SDO_YYHappyitem_Update(int GMUserID,string serverIP,int itemcode,string itemName,int level,int levPercent,int percent,int timeslimit,int dayslimit,int itemCodeBy)
		{
			int result = -1;
			SqlParameter[] paramCode;
			try
			{
				paramCode = new SqlParameter[11]{
													new SqlParameter("@Gm_UserID",SqlDbType.VarChar,20),
													new SqlParameter("@SDO_ItemCodeBy",SqlDbType.Int),
													new SqlParameter("@SDO_ServerIP",SqlDbType.VarChar,30),
													new SqlParameter("@SDO_ItemCode",SqlDbType.Int),
													new SqlParameter("@SDO_ItemName",SqlDbType.VarChar,50),
													new SqlParameter("@SDO_Level",SqlDbType.TinyInt),
													new SqlParameter("@SDO_LevPerc",SqlDbType.Int),
													new SqlParameter("@SDO_Percent",SqlDbType.Int),
													new SqlParameter("@SDO_timeslimit",SqlDbType.Int),
													new SqlParameter("@SDO_DaysLimit",SqlDbType.Int),
													new SqlParameter("@result",SqlDbType.Int)};
				paramCode[0].Value=GMUserID;
				paramCode[1].Value=itemCodeBy;
				paramCode[2].Value=serverIP;
				paramCode[3].Value=itemcode;
				paramCode[4].Value=itemName;
				paramCode[5].Value=level;
				paramCode[6].Value=levPercent;
				paramCode[7].Value=percent;
				paramCode[8].Value=timeslimit;
				paramCode[9].Value=dayslimit;
				paramCode[10].Direction = ParameterDirection.ReturnValue;
				result = SqlHelper.ExecSPCommand("SDO_YYHappyItem_Update",paramCode);
			}
			catch(SqlException ex)
			{
				Console.WriteLine(ex.Message);
			}
			return result;
		}
		#endregion
		#region ɾ��ҡҡ�ֻ�ø���
		/// <summary>
		/// ɾ��ҡҡ�ֻ�ø���
		/// </summary>
		/// <returns>�������ݼ�</returns>
		public static int SDO_YYHappyitem_Delete(int GMUserID,string serverIP,int itemcode)
		{
			int result = -1;
			SqlParameter[] paramCode;
			try
			{
				paramCode = new SqlParameter[4]{
												   new SqlParameter("@Gm_UserID",SqlDbType.VarChar,20),
												   new SqlParameter("@SDO_ServerIP",SqlDbType.VarChar,30),
												   new SqlParameter("@SDO_ItemCode",SqlDbType.Int),
												   new SqlParameter("@result",SqlDbType.Int)};
				paramCode[0].Value=GMUserID;
				paramCode[1].Value=serverIP;
				paramCode[2].Value=itemcode;
				paramCode[3].Direction = ParameterDirection.ReturnValue;
				result = SqlHelper.ExecSPCommand("SDO_YYHapppyItem_Delete",paramCode);
			}
			catch(SqlException ex)
			{
				Console.WriteLine(ex.Message);
			}
			return result;
		}
		#endregion
	}
}
